import os
import numpy as np
from skimage import io, color
from bm3d import bm3d

# Define paths
input_folder = r'C:\Users\hp\OneDrive\Documents\bm3d\input_image'
output_folder = r'C:\Users\hp\OneDrive\Documents\bm3d\output_bm3d'

# Ensure output folder exists
os.makedirs(output_folder, exist_ok=True)

# Set the noise standard deviation for BM3D
sigma = 0.4 # Example value


# Normalize function
def normalize_image(image):
    return (image - np.min(image)) / (np.max(image) - np.min(image))


# Get list of all images in the input folder
image_files = [f for f in os.listdir(input_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

for image_file in image_files:
    image_path = os.path.join(input_folder, image_file)

    try:
        # Load the image
        image = io.imread(image_path)

        # Convert to grayscale if it's a color image
        if image.ndim == 3:
            image = color.rgb2gray(image)

        # Convert image to float and normalize
        image = normalize_image(image)

        # Apply BM3D denoising
        try:
            denoised_image = bm3d(image, sigma_psd= sigma)
        except TypeError as e:
            print(f'Error in BM3D function: {e}')
            continue


        denoised_image_8bit = (denoised_image * 255).astype(np.uint8)#To Save Image In 8-bit format for JPEG saving


        output_path = os.path.join(output_folder, f'denoised_{os.path.splitext(image_file)[0]}.jpg')


        io.imsave(output_path, denoised_image_8bit)# To Save the denoised image

        print(f'Processed and saved: {output_path}')

    except Exception as e:
        print(f'Error processing {image_file}: {e}')

print('Denoising complete for all images.')
